using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ZeldaInventoryApp.Views
{
    public class _ViewStartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
