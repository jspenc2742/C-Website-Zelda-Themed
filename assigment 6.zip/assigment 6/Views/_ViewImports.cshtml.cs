using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ZeldaInventoryApp.Views
{
    public class _ViewImportsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
