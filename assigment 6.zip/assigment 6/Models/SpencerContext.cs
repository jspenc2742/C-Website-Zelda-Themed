using Microsoft.EntityFrameworkCore;

namespace ZeldaInventoryApp.Models
{
    // Database context named with your last name as required (SpencerContext)
    public class SpencerContext : DbContext
    {
        // Constructor accepting options for dependency injection configuration
        public SpencerContext(DbContextOptions<SpencerContext> options) : base(options)
        {
        }

        // DbSet representing the InventoryItems table inside the SQL Server database
        public DbSet<InventoryItem> InventoryItems { get; set; }
    }
}
