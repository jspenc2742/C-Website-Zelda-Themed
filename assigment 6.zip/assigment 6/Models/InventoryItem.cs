using System.ComponentModel.DataAnnotations;

namespace ZeldaInventoryApp.Models
{
    // Model class representing a collectible item in Hyrule's inventory database
    public class InventoryItem
    {
        // Primary Key for the database record
        public int Id { get; set; }

        [Required(ErrorMessage = "The item must have a recognized name in Hyrule.")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Item name must be between 2 and 100 characters.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please specify a category (e.g., Weapon, Armor, Elixir).")]
        public string Category { get; set; }

        [Range(1, 999, ErrorMessage = "Power rating must be a valid number between 1 and 999.")]
        public int PowerRating { get; set; }

        [Required(ErrorMessage = "Location found is required to track your adventure.")]
        public string LocationFound { get; set; }
    }
}
