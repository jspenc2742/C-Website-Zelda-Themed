using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using ZeldaInventoryApp.Models;

namespace ZeldaInventoryApp.Controllers
{
    // Controller responsible for handling Full CRUD operations for Zelda inventory items
    public class InventoryController : Controller
    {
        private readonly SpencerContext _context;

        // Injecting the SpencerContext via dependency injection
        public InventoryController(SpencerContext context)
        {
            _context = context;
        }

        // GET: Displays all items in the database (View Data)
        public async Task<IActionResult> Index()
        {
            var items = await _context.InventoryItems.ToListAsync();
            return View(items);
        }

        // GET: Returns the view for adding a new item
        public IActionResult Create()
        {
            return View();
        }

        // POST: Validates and saves a new item into the database (Add Entry)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Category,PowerRating,LocationFound")] InventoryItem item)
        {
            if (ModelState.IsValid)
            {
                _context.Add(item);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(item); // Returns form with validation errors if model state fails
        }

        // GET: Returns the view to modify an existing item
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var item = await _context.InventoryItems.FindAsync(id);
            if (item == null) return NotFound();

            return View(item);
        }

        // POST: Validates and updates an existing database record (Modify Entry)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Category,PowerRating,LocationFound")] InventoryItem item)
        {
            if (id != item.Id) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(item);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!(_context.InventoryItems.Any(e => e.Id == item.Id))) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(item);
        }

        // GET: Confirmation page for deletion
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var item = await _context.InventoryItems
                .FirstOrDefaultAsync(m => m.Id == id);
            if (item == null) return NotFound();

            return View(item);
        }

        // POST: Confirms and executes database record deletion (Delete Entry)
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var item = await _context.InventoryItems.FindAsync(id);
            if (item != null)
            {
                _context.InventoryItems.Remove(item);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
