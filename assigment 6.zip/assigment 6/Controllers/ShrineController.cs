using Microsoft.AspNetCore.Mvc;

namespace ZeldaInventoryApp.Controllers
{
    // Secondary controller handling Shrine of Light tracking stats across Hyrule
    public class ShrineController : Controller
    {
        // GET: Displays secondary views related to game progression
        public IActionResult Index()
        {
            ViewData["CompletedShrines"] = 42;
            ViewData["BlessingsFound"] = 12;
            return View();
        }
    }
}
